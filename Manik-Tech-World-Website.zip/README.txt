# Manik Tech World Website

1. Open `index.html` in a browser to preview.
2. Replace product names/prices/emoji with your real product photos and prices.
3. WhatsApp number is set to 01341673487.
4. Upload `index.html` to any static hosting service to publish.

This is a responsive single-page starter website for Manik Tech World.
